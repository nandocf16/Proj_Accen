package com.accenture.accenture.dominio;

import com.sun.istack.NotNull;

import javax.validation.constraints.Size;
import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

@Entity
@Table(name = "usuario")

public class Usuario implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @NotNull
    @Column(name = "data_Cadastro", nullable = false)
    private LocalDate dataCadastro;

    @NotNull
    @Size(max = 30)
    @Column(name = "nome", length = 30, nullable = false)
    private String nome;


    @NotNull
    @Size(max = 15)
    @Column(name = "login", length = 15, nullable = false, unique = true)
    private String login;

    @NotNull
    @Size(max = 10)
    @Column(name = "senha", length = 10, nullable = false)
    private String senha;


    @Size(max = 11)
    @Column(name = "telefone", length = 11)
    private String telefone;

    @Size(max = 100)
    @Column(name = "email", length = 100)
    private String email;

    @NotNull
    @Size(max = 1)
    @Column(name = "perfil", length = 1, nullable = false)
    private String perfil;

    @NotNull
    @Size(max = 1)
    @Column(name = "status", length = 1, nullable = false)
    private String status;

    // ___________________________________Getter e Setter__________________________________________________________

    public Long getId() {
        return this.id;
    }

    public Usuario id(Long cep) {
        this.id(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getDataCadastro() {
        return this.dataCadastro;
    }

    public Usuario dataCadastro(LocalDate dataCadastro) {
        this.dataCadastro(dataCadastro);
        return this;
    }

    public void setDataCadastro(LocalDate dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public String getNome() {
        return this.nome;
    }

    public Usuario nome(String nome) {
        this.nome(nome);
        return this;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpfCnpj() {
        return this.cpfCnpj;
    }

    public Usuario cpfCnpj(String cpfCnpj) {
        this.cpfCnpj(cpfCnpj);
        return this;
    }

    public void setCpfCnpj(String cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }

    public String getLogin() {
        return this.login;
    }

    public Usuario login(String login) {
        this.login(login);
        return this;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return this.senha;
    }

    public Usuario senha(String senha) {
        this.senha(senha);
        return this;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getTelefone() {
        return this.telefone;
    }

    public Usuario telefone(String telefone) {
        this.telefone(telefone);
        return this;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return this.email;
    }

    public Usuario email(String email) {
        this.email(email);
        return this;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPerfil() {
        return this.perfil;
    }

    public Usuario perfil(String perfil) {
        this.perfil(perfil);
        return this;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }

    public String getStatus() {
        return this.status;
    }

    public Usuario status(String status) {
        this.status(status);
        return this;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Usuario usuario = (Usuario) o;
        return login.equals(usuario.login);
    }

    @Override
    public int hashCode() {
        return Objects.hash(login);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "Usuario{" +
                "id=" + getId() +
                ", dataCadastro='" + getDataCadastro() + "'" +
                ", nome='" + getNome() + "'" +
                ", login='" + getLogin() + "'" +
                ", senha='" + getSenha() + "'" +
                ", telefone='" + getTelefone() + "'" +
                ", email='" + getEmail() + "'" +
                ", perfil='" + getPerfil() + "'" +
                ", status='" + getStatus() + "'" +
                "}";
    }
}


}


