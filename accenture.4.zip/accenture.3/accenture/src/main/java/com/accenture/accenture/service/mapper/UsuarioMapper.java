package com.accenture.accenture.service.mapper;


import com.accenture.accenture.dominio.Usuario;
import com.accenture.accenture.service.dto.UsuarioDTO;
import org.mapstruct.*;

@Mapper(componentModel = "spring", uses = {})
public interface UsuarioMapper extends EntityMapper<UsuarioDTO, Usuario> {}
