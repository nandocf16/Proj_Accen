package com.accenture.accenture.service.mapper;


import com.accenture.accenture.dominio.LivroCaixa;
import com.accenture.accenture.service.dto.LivroCaixaDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", uses = { ClienteMapper.class })
public interface LivroCaixaMapper extends EntityMapper<LivroCaixaDTO, LivroCaixa> {
    @Mapping(target = "cliente", source = "cliente", qualifiedByName = "id")
    LivroCaixaDTO toDto(LivroCaixa s);
}
