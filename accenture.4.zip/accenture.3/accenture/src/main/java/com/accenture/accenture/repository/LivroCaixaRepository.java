package com.accenture.accenture.repository;


import com.accenture.accenture.dominio.LivroCaixa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@SuppressWarnings("unused")
@Repository

        //Busca por ClienteId / Data de lançamento

public interface LivroCaixaRepository extends JpaRepository<LivroCaixa, Long> {
    Optional<List<LivroCaixa>> findByClienteId(Long clientId);
    Optional<List<LivroCaixa>> findByClienteIdAndDataLancamentoBetweenOrderByDataLancamento(Long clientId, LocalDate startDate, LocalDate endDate);
}

