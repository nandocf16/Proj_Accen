package com.accenture.accenture.repository;

import com.accenture.accenture.dominio.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@SuppressWarnings("unused")
@Repository

        //Buscar por nome ou email

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional<List<Usuario>> findByNomeOrEmail(String nome, String cpjCnpj, String cidade, String uf);

}
